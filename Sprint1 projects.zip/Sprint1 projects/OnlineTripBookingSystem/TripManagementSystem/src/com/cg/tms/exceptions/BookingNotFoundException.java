package com.cg.tms.exceptions;

public class BookingNotFoundException extends Exception {

}
