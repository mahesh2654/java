package com.cg.tms.entities;

import java.time.LocalDate;
import java.time.LocalDateTime;

public class TicketDetails {
	
	private String ticketId;
	private Route route;
	private String status;
	
	
	
	

}
