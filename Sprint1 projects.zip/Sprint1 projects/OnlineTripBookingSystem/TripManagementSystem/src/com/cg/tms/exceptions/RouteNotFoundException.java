package com.cg.tms.exceptions;

public class RouteNotFoundException extends Exception {

}
