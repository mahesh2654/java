package com.cg.tms.entities;

public class Hotel {

	private int hotelId;
	private String hotelName;
	private String hotelType;
	private String hotelDescription;
	private String address;
	private double rent;
	private String status;

}
