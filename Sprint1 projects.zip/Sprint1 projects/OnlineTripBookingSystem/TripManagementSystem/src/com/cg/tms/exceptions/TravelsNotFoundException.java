package com.cg.tms.exceptions;

public class TravelsNotFoundException extends Exception {

}
