package com.cg.tms.exceptions;

public class FeedbackNotFoundException extends Exception {

}
