package com.cg.tms.exceptions;

public class CustomerNotFoundException extends Exception{

}
