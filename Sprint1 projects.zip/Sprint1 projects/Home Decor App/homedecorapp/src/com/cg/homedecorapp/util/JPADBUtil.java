package com.cg.homedecorapp.util;

/**
 * Perform all the DB related operations, like getting entityManagerFactory object etc. 
 * @author panka
 *
 */
public class JPADBUtil {

}
