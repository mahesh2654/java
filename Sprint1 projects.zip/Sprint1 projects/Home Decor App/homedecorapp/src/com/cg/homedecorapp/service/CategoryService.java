package com.cg.homedecorapp.service;
/**
 * Create functionality as per the requirement
 * @author panka
 *
 */
public interface CategoryService {
public void save(Category category);
	public void update(Category category);
	public void delete(Long id);
	public List<Category> findAll();
}
