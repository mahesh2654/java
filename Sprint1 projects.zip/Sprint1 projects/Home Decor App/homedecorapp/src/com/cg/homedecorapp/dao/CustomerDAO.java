package com.cg.homedecorapp.dao;

import java.util.List;

import com.cg.homedecorapp.domain.Customer;

public interface CustomerDAO {

	public void save(Customer customer);
	public void update(Customer customer);
	public void delete(Long id);
	public List<Customer> findAll();
}
