package com.cg.homedecorapp.dao;

import java.util.List;

import com.cg.homedecorapp.domain.Order;

public interface OrderDAO {

	public void save(Order order);
	public void update(Order order);
	public void delete(Long id);
	public List<Order> findAll();
}
