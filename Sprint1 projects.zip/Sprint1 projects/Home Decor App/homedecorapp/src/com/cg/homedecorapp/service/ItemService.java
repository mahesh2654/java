package com.cg.homedecorapp.service;
/**
 * Create functionality as per the requirement
 * @author panka
 *
 */
public interface ItemService {
public void save(Item item);
	public void update(Item item);
	public void delete(Long id);
	public List<Item> findAll();
}
