package com.cg.homedecorapp.dao;

import java.util.List;

import com.cg.homedecorapp.domain.Category;

public interface CategoryDAO {
	public void save(Category category);
	public void update(Category category);
	public void delete(Long id);
	public List<Category> findAll();

}
