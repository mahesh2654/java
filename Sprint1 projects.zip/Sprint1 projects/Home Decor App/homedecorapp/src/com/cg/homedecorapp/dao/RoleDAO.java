package com.cg.homedecorapp.dao;

import java.util.List;

import com.cg.homedecorapp.domain.Role;

public interface RoleDAO {
	
	public void save(Role role);
	public void update(Role role);
	public void delete(Long id);
	public List<Role> findAll();
	

}
