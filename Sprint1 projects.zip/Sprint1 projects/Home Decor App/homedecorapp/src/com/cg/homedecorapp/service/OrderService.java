package com.cg.homedecorapp.service;
/**
 * Create functionality as per the requirement
 * @author panka
 *
 */
public interface OrderService {
public void save(Order order);
	public void update(Order order);
	public void delete(Long id);
	public List<Order> findAll();
}
