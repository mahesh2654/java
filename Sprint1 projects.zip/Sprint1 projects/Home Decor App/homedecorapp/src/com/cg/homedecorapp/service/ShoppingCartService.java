package com.cg.homedecorapp.service;
/**
 * Create functionality as per the requirement
 * @author panka
 *
 */
public interface ShoppingCartService {
public void save(ShoppingCart shppingCart);
	public void update(ShoppingCart shppingCart);
	public void delete(Long id);
	public List<ShoppingCart> findAll();
}
