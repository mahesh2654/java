package com.cg.homedecorapp.service;
/**
 * Create Services as per requirement
 * @author panka
 *
 */
public interface PaymentService {
public void save(Payment payment);
	public void update(Payment payment);
	public void delete(Long id);
	public List<Payment> findAll();
}
