package com.cg.homedecorapp.domain;

import java.util.Date;

public class Item {

	private Long id;
	private String itemItemtifier;
	/**
	 * FK- referenced from Category
	 */
	private Long categoryId;
	private String name;
	private String description;
	/**
	 * FK- referenced from Customer
	 */
	private Long customerId;
	private Double price;
	private Date created_At;
	private Date updated_At;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getItemItemtifier() {
		return itemItemtifier;
	}
	public void setItemItemtifier(String itemItemtifier) {
		this.itemItemtifier = itemItemtifier;
	}
	public Long getCategoryId() {
		return categoryId;
	}
	public void setCategoryId(Long categoryId) {
		this.categoryId = categoryId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Long getCustomerId() {
		return customerId;
	}
	public void setCustomerId(Long customerId) {
		this.customerId = customerId;
	}
	public Double getPrice() {
		return price;
	}
	public void setPrice(Double price) {
		this.price = price;
	}
	public Date getCreated_At() {
		return created_At;
	}
	public void setCreated_At(Date created_At) {
		this.created_At = created_At;
	}
	public Date getUpdated_At() {
		return updated_At;
	}
	public void setUpdated_At(Date updated_At) {
		this.updated_At = updated_At;
	}
	
}
