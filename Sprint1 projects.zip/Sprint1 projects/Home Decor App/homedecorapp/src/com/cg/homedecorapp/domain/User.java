package com.cg.homedecorapp.domain;

public class User extends Person {

}
