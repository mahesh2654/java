package com.cg.homedecorapp.dao;

import java.util.List;

import com.cg.homedecorapp.domain.Item;

public interface ItemDAO {
	public void save(Item item);
	public void update(Item item);
	public void delete(Long id);
	public List<Item> findAll();
}
