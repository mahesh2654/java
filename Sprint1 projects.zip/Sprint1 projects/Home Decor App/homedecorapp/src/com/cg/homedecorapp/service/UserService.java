package com.cg.homedecorapp.service;
/**
 * This Service should have functionality as per the requirement
 * @author panka
 *
 */
public interface UserService {
public void save(User user);
	public void update(User user);
	public void delete(Long id);
	public List<User> findAll();
}
