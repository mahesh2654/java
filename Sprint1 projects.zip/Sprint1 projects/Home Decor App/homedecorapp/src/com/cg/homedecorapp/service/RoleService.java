package com.cg.homedecorapp.service;
/**
 * Create functionality as per the requirement
 * @author panka
 *
 */
public interface RoleService {
public void save(Role role);
	public void update(Role role);
	public void delete(Long id);
	public List<Role> findAll();
}
