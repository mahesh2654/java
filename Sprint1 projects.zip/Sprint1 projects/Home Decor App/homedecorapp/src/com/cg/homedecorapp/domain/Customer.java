package com.cg.homedecorapp.domain;

public class Customer extends Person {
	
	private Address address;

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}
	

}
