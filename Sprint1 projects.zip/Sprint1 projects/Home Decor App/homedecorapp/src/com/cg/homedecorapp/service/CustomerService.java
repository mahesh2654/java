package com.cg.homedecorapp.service;

import java.util.List;

import com.cg.homedecorapp.domain.Customer;

public interface CustomerService {

	public void save(Customer customer);
	public void update(Customer customer);
	public void delete(Long id);
	public List<Customer> findAll();
}
