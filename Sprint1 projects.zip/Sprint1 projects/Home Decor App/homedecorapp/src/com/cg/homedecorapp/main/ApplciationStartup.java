package com.cg.homedecorapp.main;

import com.cg.homedecorapp.util.MenuUtil;

public class ApplciationStartup {
	public static void main(String[] args) {
		MenuUtil menuUtil =  new MenuUtil();
		menuUtil.start();
	}

}
