package com.cg.homedecorapp.dao;

import java.util.List;

import com.cg.homedecorapp.domain.ShoppingCart;

public interface ShoppingCartDAO {
	public void save(ShoppingCart shppingCart);
	public void update(ShoppingCart shppingCart);
	public void delete(Long id);
	public List<ShoppingCart> findAll();
}
