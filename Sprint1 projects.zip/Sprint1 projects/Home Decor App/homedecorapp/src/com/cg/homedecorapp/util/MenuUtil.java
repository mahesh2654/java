package com.cg.homedecorapp.util;

public class MenuUtil {

	public void start() {
		// TODO Auto-generated method stub
		
	}

}
