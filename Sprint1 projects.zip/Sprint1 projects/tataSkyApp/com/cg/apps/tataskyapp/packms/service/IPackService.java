package com.cg.apps.tataskyapp.packms.service;

import com.cg.apps.tataskyapp.packms.entities.Pack;

import java.util.List;

public interface IPackService {
    Pack add(Pack pack);

    Pack update(Pack pack);

    Pack findPackById(Long packId);

    List<Pack>findPacksGreaterThanAmount(double amount);

    List<Pack>findPacksInAscendingOrderByCost();

    List<Pack> findPacksInAscendingOrderByDaysValidity();

    /**
     * finds packs in descending order of popularity
     *  popularity is measured by number of recharges done on a pack
     */
    List<Pack> popularPacks();


    void deleteByPackId(Long packId);
}
