package com.cg.apps.tataskyapp.packms.repository;

import com.cg.apps.tataskyapp.packms.entities.Pack;

import java.util.List;

public interface IPackRepository {

    Pack add(Pack pack);

    Pack update(Pack pack);

    Pack findPackById(Long packId);

    List<Pack>findPacksGreaterThanAmount(double amount);

    List<Pack>findPacksInAscendingOrderByCost();

    List<Pack> findPacksInAscendingOrderByDaysValidity();

    void deleteByPackId(Long packId);


}
