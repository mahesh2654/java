package com.cg.apps.tataskyapp.accountms.service;

import com.cg.apps.tataskyapp.accountms.entities.Account;
import com.cg.apps.tataskyapp.packms.entities.Pack;

import java.time.LocalDate;

public interface IAccountService {

	 Account add(Account account);

    Account findById(Long accountId) ;

    Account update(Account account);

    void deleteByAccountId(Long accountId);

    int countCreatedAccountsInPeriod(LocalDate startDate, LocalDate endDate);

    int countCreatedAccounts(LocalDate startDate, LocalDate endDate);

    /**
     * finds count of accounts in the application
     */
    int countAccounts();

    void removePackForAccount(Account account, Pack pack);

}
