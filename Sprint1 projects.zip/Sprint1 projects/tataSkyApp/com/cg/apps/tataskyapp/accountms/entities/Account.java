package com.cg.apps.tataskyapp.accountms.entities;

import com.cg.apps.tataskyapp.userms.entities.User;
import com.cg.apps.tataskyapp.packms.entities.Pack;
import com.cg.apps.tataskyapp.rechargems.entities.Recharge;
import com.cg.apps.tataskyapp.servicerequestms.entities.ServiceRequest;

import java.time.LocalDate;
import java.util.List;

public class Account {
    private Long accountId;
    private User user;
    private List<Recharge>recharges;
    private LocalDate registeredDate;
    private List<ServiceRequest>requests;
    private Pack currentPack;

    public Long getAccountId() {
        return accountId;
    }

    public void setAccountId(Long accountId) {
        this.accountId = accountId;
    }

    public User getCustomer() {
        return user;
    }

    public void setCustomer(User user) {
        this.user = user;
    }

    public List<Recharge> getRecharges() {
        return recharges;
    }

    public void setRecharges(List<Recharge> recharges) {
        this.recharges = recharges;
    }
    public LocalDate getRegisteredDate() {
        return registeredDate;
    }

    public void setRegisteredDate(LocalDate registeredDate) {
        this.registeredDate = registeredDate;
    }

    public List<ServiceRequest> getRequests() {
        return requests;
    }

    public void setRequests(List<ServiceRequest> requests) {
        this.requests = requests;
    }

    public Pack getCurrentPack() {
        return currentPack;
    }

    public void setCurrentPack(Pack currentPack) {
        this.currentPack = currentPack;
    }
}
