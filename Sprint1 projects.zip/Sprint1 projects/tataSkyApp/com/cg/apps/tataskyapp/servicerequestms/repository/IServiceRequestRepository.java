package com.cg.apps.tataskyapp.servicerequestms.repository;

import com.cg.apps.tataskyapp.accountms.entities.Account;
import com.cg.apps.tataskyapp.servicerequestms.entities.ServiceRequest;

import java.time.LocalDate;
import java.util.List;

public interface IServiceRequestRepository {
    ServiceRequest add(ServiceRequest request);

    ServiceRequest update(ServiceRequest request);

    ServiceRequest findOpenedServiceRequest(Account account);

}
