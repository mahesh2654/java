package com.cg.apps.tataskyapp.servicerequestms.service;

import com.cg.apps.tataskyapp.accountms.entities.Account;
import com.cg.apps.tataskyapp.servicerequestms.entities.ServiceRequest;


public interface IServiceRequestService {

    /**
     * create new service request only if there is not an already existing opened service request
     */
    ServiceRequest createServiceRequestForUser(Account account);

    ServiceRequest openedServiceRequest(Account account);

    ServiceRequest close(Long serviceRequestId);
}
