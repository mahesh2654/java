package com.cg.apps.tataskyapp.servicerequestms.entities;

import com.cg.apps.tataskyapp.accountms.entities.Account;
import com.cg.apps.tataskyapp.packms.entities.Pack;

import java.time.LocalDate;

public class ServiceRequest {
    private Long id;
    private LocalDate requestedDate;
    private Account account;
    private String message;

    // make it true when request is created, false when user has created a recharge
    private Boolean statusOpened;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }


    public LocalDate getRequestedDate() {
        return requestedDate;
    }

    public void setRequestedDate(LocalDate requestedDate) {
        this.requestedDate = requestedDate;
    }

    public Account getAccount() {
        return account;
    }

    public void setAccount(Account account) {
        this.account = account;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Boolean isStatusOpened() {
        return statusOpened;
    }

    public void setStatusOpened(Boolean statusOpened) {
        this.statusOpened = statusOpened;
    }

}

