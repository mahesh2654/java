package com.cg.apps.tataskyapp.userms.repository;

import com.cg.apps.tataskyapp.userms.entities.User;

public interface IUserRepository {
    User add(User user);

    User update(User user);

    User findById(Long id);

    User findByUsername(String username);

    void deleteByUserId(Long customerId);

}
