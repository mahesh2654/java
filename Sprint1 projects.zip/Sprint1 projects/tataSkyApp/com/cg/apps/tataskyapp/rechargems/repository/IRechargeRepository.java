package com.cg.apps.tataskyapp.rechargems.repository;

import com.cg.apps.tataskyapp.accountms.entities.Account;
import com.cg.apps.tataskyapp.packms.entities.Pack;
import com.cg.apps.tataskyapp.rechargems.entities.Recharge;

import java.time.LocalDate;
import java.util.List;

public interface IRechargeRepository {

    Recharge add(Recharge recharge);

    Recharge update(Recharge recharge);

    List<Recharge> findRechargesForUserInDescendingOrderByPurchasedDate(Account account);

    int rechargesForUserCount(Account account);

    List<Recharge> findAllRechargesInPeriod(LocalDate startDate, LocalDate endDate);

    int countRechargesInPeriod(LocalDate startDate, LocalDate endDate);
    /**
     * calculates revenue by add of all recharges
     */
    double totalRevenueInPeriod(LocalDate startDate, LocalDate endDate);

    int rechargesCount(Pack pack);

}
