package com.cg.apps.tataskyapp.rechargems.entities;

import com.cg.apps.tataskyapp.accountms.entities.Account;
import com.cg.apps.tataskyapp.constants.PlanStatus;
import com.cg.apps.tataskyapp.packms.entities.Pack;

import java.time.LocalDate;
import java.util.List;

public class Recharge {
    private Long id;
    private Account account;
    private Double amount;
    private Integer daysValidity;
    private String planDescription;
    private String planName;
    private LocalDate purchasedDate;
    private List<String> channels;
    private Pack pack;

    private boolean active;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Account getAccount() {
        return account;
    }

    public void setAccount(Account account) {
        this.account = account;
    }

    public Double getAmount() {
        return amount;
    }

    public void setAmount(Double amount) {
        this.amount = amount;
    }

    public Integer getDaysValidity() {
        return daysValidity;
    }

    public String getPlanName() {
        return planName;
    }

    public void setPlanName(String planName) {
        this.planName = planName;
    }

    public void setDaysValidity(Integer daysValidity) {
        this.daysValidity = daysValidity;
    }

    public String getPlanDescription() {
        return planDescription;
    }

    public void setPlanDescription(String planDescription) {
        this.planDescription = planDescription;
    }

    public LocalDate getPurchasedDate() {
        return purchasedDate;
    }

    public void setPurchasedDate(LocalDate purchasedDate) {
        this.purchasedDate = purchasedDate;
    }

    public List<String> getChannels() {
        return channels;
    }

    public void setChannels(List<String> channels) {
        this.channels = channels;
    }

    public Pack getPack() {
        return pack;
    }

    public void setPack(Pack pack) {
        this.pack = pack;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }
}
