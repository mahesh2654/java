package com.cg.blogging.entities;

import java.util.List;

public class Award {
private List<Coin> coin;

public List<Coin> getCoin() {
	return coin;
}

public void setCoin(List<Coin> coin) {
	this.coin = coin;
}


}
