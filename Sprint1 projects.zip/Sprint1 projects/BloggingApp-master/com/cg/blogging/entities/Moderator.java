package com.cg.blogging.entities;

public class Moderator extends Blogger {
	
	public boolean moderatesPostsAndComments() {return false;}

}
