package com.cg.blogging.entities;

public class Comment {
private int commentId;
private String commentDescription;
private int votes;
private Blogger blogger;
private Post post;
private boolean voteUp;


}
