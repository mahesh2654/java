package com.cg.blogging.entities;

import java.util.List;

public class Blogger {
	private int userId;
	private String bloggerName;
	private List<Post> posts;
	private List<Comment> comments;
	private List<Post> upvoted;
	private List<Post> downvoted;
	private Award awardsReceived;
	private Award awardsGiven;
	private List<Community> communities;
	private int karma;
	
	
	
	
		
	
	
	
	

}
