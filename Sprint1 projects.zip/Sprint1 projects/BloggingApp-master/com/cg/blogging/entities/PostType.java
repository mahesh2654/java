package com.cg.blogging.entities;

public enum PostType {
TEXT,VIDEO_IMAGE,LINK,POLL;
}
