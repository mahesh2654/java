package com.cg.blogging.entities;

public class Admin {
private int userId;
private String adminName;
private String adminContact;
}
