package com.cg.blogging.exception;

public class NotEnoughPointsException extends Exception {

	public NotEnoughPointsException() {
		super();
		// TODO Auto-generated constructor stub
	}

	

	public NotEnoughPointsException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}


	
}
