import java.util.Arrays;
import java.util.List;
import java.util.stream.IntStream;

public class Main {

	public static void main(String[] args) {
		List<String> cities = Arrays.asList(
				"Hyderabad", "Delhi", "Kanpur", "Pune", 
				"Mumbai", "Chennai", "KolKotta",
				"Amaravati", "Bhopal", "Kochi");
// Display cities whose name starts with 'K' in ascending order in uppercase
		cities.stream()
		.filter(s -> s.startsWith("K"))
		.map(String::toUpperCase)
		.sorted()
		.forEach(System.out::println);

	}

}
