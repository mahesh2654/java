import java.util.Arrays;
import java.util.List;
import java.util.stream.IntStream;

public class Main {

	public static void main(String[] args) {

	List<Integer> numbers = Arrays.asList(10,15,20,25,30,35,40,45,50);
	
	// Display all the above integers and sum at the end
	
	int sum= 
		numbers
		.stream()
	    .peek(System.out::println)
	    .mapToInt(x->x.intValue())
	    .sum();
	 System.out.println("Sum: "+sum);   
	}

}
