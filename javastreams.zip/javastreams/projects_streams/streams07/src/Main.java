import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

public class Main {

	public static void main(String[] args) {


		List<Employee> empList = Arrays.asList(
				        new Employee(100, "Shashi", 15000, 10), 
				        new Employee(200, "Kishore", 15000, 20),
				        new Employee(300, "Ramana", 8000, 10), 
				        new Employee(800, "Rekha", 45000, 20), 
				        new Employee(400, "Sridhar", 12000, 30),
				        new Employee(600, "Suraj", 15000, 20), 
				        new Employee(500, "Alok", 26000, 10), 
				        new Employee(900, "Kiran", 6700, 30),
				        new Employee(700, "Zahur", 2300, 20),
				        new Employee(150,"Andrews",12000,30)
				 );

//	Create TreeMap with empId as Key and Employee as value
		
		Map<Integer,Employee> map=
				empList
				.stream()
				.collect(Collectors.toMap(Employee::getEmpId, Function.identity(),(oldValue,newValue) -> oldValue,TreeMap::new));	
				
				
		map.forEach((k,v)-> {System.out.println("Key: "+k+"\tData: "+v);});

	}
}