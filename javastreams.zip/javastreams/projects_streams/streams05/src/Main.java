import java.util.*;
import java.util.stream.Collectors;

public class Main {

	public static void main(String[] args) {
	
		List<String> names = Arrays.asList("Amitabh","Shekhar","Aman",
				                           "Rahul","Shahrukh","Salman",
				                           "Yana","Lokesh");

		// convert list of names to TreeSet of uppercase names
		TreeSet<String> set=
		  names.stream()
            .map(String::toUpperCase)
            .collect(Collectors.toCollection(TreeSet::new));
		
          set.forEach(System.out::println);

		
	}

}
