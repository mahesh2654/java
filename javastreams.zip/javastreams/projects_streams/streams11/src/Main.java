import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

public class Main {

	
	public static void main(String[] args) {


		List<Person> persons = Arrays.asList(
					new Person("Anil", "21-09-1966"),
					new Person("Sujatha", "05-09-1966"),
					new Person("Sudhir", "15-08-1982"),
					new Person("Ajay", "08-01-1960"),
					new Person("Prerana", "10-02-1959"),
					new Person("Parihar", "21-11-1982"),
					new Person("Kishore", "18-09-1982"),
					new Person("Peter", "28-06-1977"),
					new Person("Dolly", "25-07-1993"),
					new Person("Nidhi", "07-07-1993"),
					new Person("Naresh", "17-11-1977")
				 );

//	Create a TreeMap grouping Persons on their age
		
		Map<Integer,List<Person>> map= 
				persons
				.stream()
				.collect(Collectors.groupingBy(Person::getAge,TreeMap::new,Collectors.toList()));
		 
		
		map.forEach((k,v)-> {System.out.println(k+"\t"+v);});

	}
}