
import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class Person {

	private String name;
	private LocalDate birthDate;

	public Person(String name, String birthDate) {
		this.name = name;
		this.birthDate = LocalDate.parse(birthDate, DateTimeFormatter.ofPattern("dd-MM-yyyy"));
	}

	public String getName() {
		return name;
	}

	public LocalDate getBirthDate() {
		return birthDate;
	}

	public int getAge() {
		return Period.between(birthDate, LocalDate.now()).getYears();
	}

	public String toString() {
		return name;
	}

}
