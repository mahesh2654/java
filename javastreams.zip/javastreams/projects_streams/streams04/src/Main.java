import java.util.Arrays;
import java.util.List;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class Main {

	public static void main(String[] args) {

		List<String> cities = Arrays.asList(
				"Hyderabad", "Delhi", "kanpur", "Pune", 
				"Mumbai", "Chennai", "KolKotta",
				"Amaravati", "Bhopal", "Kochi");
		
//Display all city names in reverse order
			
	cities.stream()
	   .map(StringBuffer::new)
	   .map(t->t.reverse().toString())
	   .forEach(System.out::println);
	}	
}
