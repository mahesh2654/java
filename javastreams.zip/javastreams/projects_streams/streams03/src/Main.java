import java.util.Arrays;
import java.util.List;
import java.util.stream.IntStream;

public class Main {

	public static void main(String[] args) {

// Create a stream of integers in the rage of 10 to 15 
// and display the average of the squares using streams
		
		IntStream.rangeClosed(10, 15)
		.map(n -> n * n)
	    .average()
	    .ifPresent(x->System.out.printf("%.2f",x));  
	}

}
