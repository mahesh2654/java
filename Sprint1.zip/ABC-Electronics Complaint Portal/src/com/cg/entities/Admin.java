package com.cg.entities;

public class Admin {

	private int adminId; // work like as employee id
	private String password;
	private long contactNumber;
	private String emailId;
	
	
}
