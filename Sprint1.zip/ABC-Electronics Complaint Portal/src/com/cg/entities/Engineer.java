package com.cg.entities;

import java.util.List;

public class Engineer {
	
	private int employeeId; // treat like login id
	private String password;
	private String engineerName;
	private String domain; // like washing machine , AC, Mobile phone
	private List<Complaint> complaints;
	
	
}
