package com.cg.exceptions;

public class InValidComplaintIdException extends Exception {

}
