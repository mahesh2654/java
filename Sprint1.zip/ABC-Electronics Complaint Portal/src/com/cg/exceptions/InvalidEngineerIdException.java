package com.cg.exceptions;

public class InvalidEngineerIdException extends Exception {

}
