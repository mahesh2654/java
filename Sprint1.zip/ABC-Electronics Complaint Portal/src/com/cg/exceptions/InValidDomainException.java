package com.cg.exceptions;

public class InValidDomainException extends Exception {

}
