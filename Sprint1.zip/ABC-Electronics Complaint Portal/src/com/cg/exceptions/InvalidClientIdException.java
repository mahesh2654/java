package com.cg.exceptions;

public class InvalidClientIdException extends Exception {

}
