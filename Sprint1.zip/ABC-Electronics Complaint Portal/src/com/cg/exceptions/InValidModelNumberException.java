package com.cg.exceptions;

public class InValidModelNumberException extends Exception {

}
