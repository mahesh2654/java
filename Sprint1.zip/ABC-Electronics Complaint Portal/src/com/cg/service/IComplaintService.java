package com.cg.service;

import java.util.List;

import com.cg.entities.Client;
import com.cg.entities.Complaint;
import com.cg.entities.Engineer;
import com.cg.entities.Product;
import com.cg.exceptions.InValidComplaintIdException;
import com.cg.exceptions.InValidDomainException;
import com.cg.exceptions.OutOfWarrantyException;

public interface IComplaintService {

	public boolean bookComplaint(Client clinet,Complaint complaint,Product product)throws OutOfWarrantyException;
	public String changeComplaintStatus(Complaint complaintId);
	
	public List<Complaint> getClientAllComplaints(Client client);
	public List<Complaint> getClientAllOpenComplaints(Client client);
	
	public Engineer getEngineer(int complaintId)throws InValidComplaintIdException;
	public Product getProductByComplaint(int complaintId)throws InValidComplaintIdException;
	
}
