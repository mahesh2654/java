package com.cg.service;

import java.util.List;

import com.cg.entities.Client;
import com.cg.entities.Engineer;
import com.cg.exceptions.InvalidClientIdException;
import com.cg.exceptions.InvalidEngineerIdException;

public interface IClientService {

	public void saveClient(Client c);
	public Client getClientByCLientId(String clientId)throws InvalidClientIdException ;
	
	
	public Engineer getEngineerById(int id) throws InvalidEngineerIdException;
	public List<Engineer> getEngineersByDomain(String category);
	public String chnageStatusOfComplaint(int complaintId); // returns updated Status , can close the complaint if problem resolve
	
	public Client signIn(Client client);
	public Client signOut(Client client);

}
