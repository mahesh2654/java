package com.capgemini.model;

/**
 * 
 * List of RTO offices in Maharashtra
 */
public class RTOOffice {
	private int rtoId;
	private String rtoName;
}
