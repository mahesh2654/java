package com.capgemini.model;

public class Challan {
	private String challanNumber;
	private String vehicleNumber;
	private double amount;
}
