package com.capgemini.model;

public class RTOOfficer {
	private String username;
	private String password;
	private String email;
	private RTOOffice office;
}
