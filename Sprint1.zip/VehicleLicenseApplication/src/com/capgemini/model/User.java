package com.capgemini.model;
/**
 * 
 * This class will have details of applcation user
 *
 */
public class User {
	private String email;
	private String password;
}
