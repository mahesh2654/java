package com.capgemini.model;

public class Documents {
	// necessary documents need to upload
	private String photo;
	private String idProof;
	private String addressProof;
}
