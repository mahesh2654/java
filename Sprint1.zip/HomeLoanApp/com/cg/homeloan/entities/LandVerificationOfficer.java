package com.cg.homeloan.entities;

public class LandVerificationOfficer {
	
	private int userId;
	private String officerName;
	private String officerContact;

}
