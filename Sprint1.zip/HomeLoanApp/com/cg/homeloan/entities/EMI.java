package com.cg.homeloan.entities;

import java.time.LocalDate;

public class EMI {
	
	private long EMIId;
	private LocalDate dueDate;
	private double emiAmount;
	private double loanAmount;
	private double interestAmount;
	private long loanAgreementId;
	

}
