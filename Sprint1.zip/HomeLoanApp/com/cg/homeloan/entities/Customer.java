package com.cg.homeloan.entities;

import java.time.LocalDate;

public class Customer {
private String userId;
private String customerName;
private String mobileNumber;
private String emailId;
private LocalDate dateOfBirth;
private String gender;
private String nationality;
private String aadharNumber;
private String panNumber;





}
