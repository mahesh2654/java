package com.cg.homeloan.entities;

public class FinanceVerificationOfficer {

	private int userId;
	private String finOfficerName;
	private String finOfficerContact;
}
