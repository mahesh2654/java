package com.cg.homeloan.entities;

public class LoanAgreement {
	private long loanAgreementId;
	private long loanApplicationId;
	private EMI emi;
	

}
