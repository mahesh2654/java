package com.cg.homeloan.exception;

public class LandVerificationException extends Exception{

	public LandVerificationException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public LandVerificationException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}
	
	

}
