package com.cg.homeloan.exception;

public class FinanceVerificationException extends Exception {

	public FinanceVerificationException() {
		super();
		// TODO Auto-generated constructor stub
	}

	

	public FinanceVerificationException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}


	
}
