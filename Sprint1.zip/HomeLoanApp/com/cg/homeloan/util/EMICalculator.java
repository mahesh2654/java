package com.cg.homeloan.util;

public class EMICalculator {

	private double loanAmount;
	private double rateOfInterest;
	private int tenure;
	
	
	public double getEMIAmount(){return  0;};
	
}
