package com.cg.homeloan.util;

public class HomeLoanBorrowingAmountCalculator {

	private double loanAmount;
	private double rateOfInterest;
	private int tenure;
	private double totalAnnualIncome;
	private double monthlyExpenses;
	private double otherMonthlyExpenses;
	
	public double getHomeLoanBorrowingAmount() {return 0;}
	
}
