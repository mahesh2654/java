package com.cg.dca.exception;

public class UnknownDeveloperException extends Exception {

}
