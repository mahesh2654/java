package com.cg.dca.exception;

public class UnknownResponseException extends Exception {

}
