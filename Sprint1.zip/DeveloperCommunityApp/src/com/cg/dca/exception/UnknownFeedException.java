package com.cg.dca.exception;

public class UnknownFeedException extends Exception {

}
