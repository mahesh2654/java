package com.cg.dca.entity;

public class User {
	private String userId;
	private String password;
	private String role;
}
