package com.cg.aps.entities;

import java.util.Date;

public class DeliveryEntity extends BaseEntity {

	private String ownerName;
	private String time;
	private Date date;
	private String status;
	
	@Override
	public String getKey() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getValue() {
		// TODO Auto-generated method stub
		return null;
	}

}
