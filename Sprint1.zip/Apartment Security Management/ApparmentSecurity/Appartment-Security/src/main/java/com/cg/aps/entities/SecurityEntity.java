package com.cg.aps.entities;

public class SecurityEntity extends BaseEntity {

	private String message;
	private String alert;
	
	@Override
	public String getKey() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getValue() {
		// TODO Auto-generated method stub
		return null;
	}

}
