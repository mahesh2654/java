package com.cg.aps.entities;

import java.util.Date;

public class VisitorEntity extends BaseEntity {

	private String name;
	private String ownerName;
	private String flatNo;
	private Date date;
	private String arrivalTime;
	private String departureTime;
	
	@Override
	public String getKey() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getValue() {
		// TODO Auto-generated method stub
		return null;
	}

}
